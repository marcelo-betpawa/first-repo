#!/usr/bin/env python3
""" Command Line Jstack tool for Kubernetes environments

Features:
    * Connect to K8s Clusters
    * Retrieve Pods(podname, application, namespace)
    * Collect Thread Dumps from pods
    * Upload a file to AWS S3 bucket
    * Restart applications non-statefulset on K8s
"""
import argparse
import logging
import sys

from os import environ
from kubernetes.client.rest import ApiException

from jstack.lib.k8s import (connect_to_cluster,
                            list_pod_namespace,
                            collect_thread_dumps,
                            restart_application)
from jstack.lib.aws import upload_file


def main():
    """ Main function to run the CLI
    """
    base = "[%(asctime)s] [%(levelname)s] [%(name)s] "\
           "[%(funcName)s():%(lineno)s] [PID:%(process)d TID:%(thread)d] "\
           " %(message)s"
    time_control = "%d/%m/%Y %H:%M:%S"

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(base, time_control))

    log = logging.getLogger(__name__)
    log.addHandler(handler)
    log.setLevel(logging.INFO)

    parser = argparse.ArgumentParser()

    parser.add_argument('-r', '--restart',
                        action='store_true',
                        help="restart the applications")

    parser.add_argument('-a', '--apps',
                        action='store',
                        required=True,
                        type=str,
                        help="list of applications to collect thread dumps." \
                             "e.g ./jstack -a \"cms, external\"")

    args = parser.parse_args()

    mandatory_env_vars = ["AWS_ACCESS_KEY_ID",
                          "AWS_SECRET_ACCESS_KEY"]

    log.info('Checking credentials...')

    for var in mandatory_env_vars:
        if var not in environ:
            raise EnvironmentError(f'Failed because {var} is not set.')

    if args.apps:
        log.info('Connecting to K8s Cluster...')

        try:
            conn = connect_to_cluster()

        except ApiException as error:
            raise ApiException(f"Please check the credentials of K8s cluster! \n" \
                               f"ERROR: {error}")

        log.info('Retrieving PODS...')
        pods_dict = list_pod_namespace(connection=conn, apps=args.apps)
        log.info('Collecting Thread Dumps...')
        get_files = collect_thread_dumps(connection=conn, apps_dict=pods_dict)

        log.info('Uploading files to AWS S3 bucket...')

        exit()

        for handle_file in get_files:
            upload_file(file_name=handle_file,
                        bucket='betpawa-dumps-gcheap',
                        object_name=None,
                        delete=True)

            log.info(' %s', handle_file)

    if args.restart:
        log.info('Restarting Applications...')
        rest = restart_application(apps_dict=pods_dict)

        for retrieve_pod in rest:
            log.info(' restarted %s namespace', retrieve_pod)


if __name__ == "__main__":
    main()
