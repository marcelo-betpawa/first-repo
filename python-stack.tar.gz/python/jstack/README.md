python-jstack
======

The python-jstack tool for kubernetes environments can be used on this sceneries:

* To collect Thread Dumps for any Java Application running on Kubernetes.
* Get the list of pods from an application.
* Upload files to AWS S3 bucket name.
* Restart any application on K8s.


The ``python-jstack`` command
------------------------------
The ``python-jstack`` command has the following options:

- ``--apps (-a)``:
  a list of application that it's running into Kubernetes

- ``--restart (-r)``:
  to restart the application or an list fo any applications


Example
-------
To restart and collect the Thread Dumps of an application:

```
$ python-jstack -a "cms, external" -r
```

**Only** to collect the Thread Dumps for an application:

```
$ python-jstack -a "version-checker"
```

Developement Mode
-----------------

To start the development or maintenance starts using:

```
$ python3 setup.py develop --user
```

How to Install
----------

```
$ python3 -m pip install .
$ python3 -m pip install -r requirements.txt
```