""" Setup file of Jstack tool
"""
import os
from setuptools import setup, find_packages


def load_readme(fname):
    """ Function to read the README.md file adding the
        content in the long_description field

    Arguments:
      fname {string} -- name of file that describes the tool
    """
    return open(os.path.join(os.path.dirname(__file__), fname)).read()


setup(name="jstack",
      version="0.0.1",
      author="Marcelo Barbosa",
      author_email="marcelo.barbosa@betpawa.com",
      description=("JSTack Tool for collect Thread Dumps and restart the services\
                    Kubernetes environments"),
      long_description=load_readme('README.md'),
      packages=find_packages(),
      python_requires='>=3.5',
      install_requires=['kubernetes>=10.0.1', 'botocore>=1.14.9', 'boto3>=1.11.9'],
      entry_points={'console_scripts': ['python-jstack = jstack.cli.cli:main']})
