""" Jstack libraries to work with aws services
"""
from os import remove
import datetime

from botocore.exceptions import ClientError

import boto3


def upload_file(file_name, bucket, application, delete=False):
    """ Function to upload a file to an AWS S3 bucket

    Param:
        file_name: File to upload to AWS S3 bucket
        bucket: Bucket name that will be used in upload process
        application: Name of application that will be used to
                     create the object_name
        delete: Delete the file uploaded to AWS S3 bucket. if not
                specified will not delete if specified True will
                delete the file

    Returns:
        [boolean] --    True if file was uploaded or False with error in case of a
        client issue
    """
    folder = f"{datetime.datetime.now():%Y-%m-%d-%H}"
    path = f"jstack/{application}/{folder}"
    object_name = f"{path}/{file_name}"

    try:
        s3_client = boto3.client('s3')
        s3_client.upload_file(file_name, bucket, object_name)

        if delete is True:
            remove(file_name)

        return True

    except ClientError as error:
        return False, error
