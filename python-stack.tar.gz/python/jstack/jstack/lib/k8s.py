""" Jstack libraries to work with Kubernetes
"""
import subprocess

from kubernetes import client, config
from kubernetes.stream import stream


def connect_to_cluster():
    """ Function to creates a stream connection to
    Kubernetes Cluster

    Returns:
        connection stream -- a stream connection object
    """
    try:
        config.load_kube_config()

    except TypeError:
        config.load_incluster_config()

    con_v1 = client.CoreV1Api()

    return con_v1


def list_pod_namespace(connection, apps):
    """ Function to retrieve a Podname and Namespace from an application

    Arguments:
        connection {connection stream} -- The stream connection object to
                                          communicates with the K8s Cluster
        apps {list} -- List of applications

    Returns:
        dict -- a dict {'podname': {'application': 'namespace'}}
    """
    list_apps = list(apps.split(","))
    pod_dict = {}

    for app in list_apps:
        string_query = "app={0}".format(app.strip())
        list_of_pods = connection.list_pod_for_all_namespaces(label_selector=string_query,
                                                              watch=False)

        for i in list_of_pods.items:
            pod_dict[i.metadata.name] = {f"{app.strip()}": f"{i.metadata.namespace}"}

    return pod_dict


def collect_thread_dumps(connection, apps_dict):
    """ That function collects the thread dumps of a
    list of applications received

    Arguments:
        connection {connection stream} -- The stream connection object to
                                          communicates with the K8s Cluster
        apps_dict {dict} -- Dictionary generates by list_pod_namespace()

    Returns:
        dict -- Files names generated and application of that
    """
    files = {}

    for pod in apps_dict:
        podname = pod

        for data in apps_dict[pod].items():
            application = data[0]
            namespace = data[1]

            pid_command = ['/bin/bash', '-c', 'pidof java']

            pid = stream(connection.connect_get_namespaced_pod_exec,
                         name=podname,
                         namespace=namespace,
                         command=pid_command,
                         stderr=True, stdin=False,
                         stdout=True, tty=False)

            jstack_command = ['jstack', '-l', '{0}'.format(pid)]

            jstack = stream(connection.connect_get_namespaced_pod_exec,
                            name=podname,
                            namespace=namespace,
                            command=jstack_command,
                            stderr=True, stdin=False,
                            stdout=True, tty=False)

            file_jstack = open("{0}-{1}.txt".format(namespace, podname), "w")
            file_jstack.write(jstack)
            file_jstack.close()
            files[f"{namespace}-{podname}.txt"] = application

    return files


def restart_application(apps_dict):
    """ Function to restart the applications of Kubernetes

    Arguments:
        apps_dict {dict} -- dict generates by list_pod_namespace()

    Returns:
        list -- a list with applications in what namespace was
                rebooted
    """
    restarts = []

    for pod in apps_dict.keys():

        for data in apps_dict[pod].items():
            application = data[0]
            namespace = data[1]

            if application is not None or namespace is not None:
                try:
                    subprocess.run(["kubectl", "rollout",
                                    "restart", f"deployment/{application}",
                                    "-n", f"{namespace}"],
                                   stdout=subprocess.DEVNULL, check=True)

                    restarts.append(f"{application} in {namespace}")

                except subprocess.CalledProcessError as error:
                    return error

    return restarts
